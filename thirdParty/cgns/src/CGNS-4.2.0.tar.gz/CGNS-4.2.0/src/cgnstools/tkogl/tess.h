int Tesselate (Tcl_Interp *interp, int argc, char* argv []);


